// See https://github.com/dialogflow/dialogflow-fulfillment-nodejs
// for Dialogflow fulfillment library docs, samples, and to report issues
'use strict';
 
const functions = require('firebase-functions');
const {WebhookClient} = require('dialogflow-fulfillment');
const {Card, Suggestion}=require('dialogflow-fulfillment');
const firebaseAdmin = require('firebase-admin');


process.env.DEBUG = 'dialogflow:debug'; // enables lib debugging statements
 
firebaseAdmin.initializeApp({
  credential: firebaseAdmin.credential.applicationDefault(),
  databaseURL: 'ws://farmeragent-b7add-default-rtdb.firebaseio.com/',
});

exports.dialogflowFirebaseFulfillment = functions.https.onRequest((request, response) => {
  const agent = new WebhookClient({ request, response });
  console.log('Dialogflow Request headers: ' + JSON.stringify(request.headers));
  console.log('Dialogflow Request body: ' + JSON.stringify(request.body));
 
  function welcome(agent) {
    var dateTime = new Date();
    agent.add('La hora es: ' + dateTime);
    agent.add(`Yo soy Diego tu agro asistente y puedo ayudarte a Saber el estado del clima de tu localización, conocer si debes de regar tu cultivo, conocer las semillas, periodo de siembra y alguna otra información de tu interés sobre lo próximo a plantar en tu región y en otras partes de Latinoamérica y en Caribe. Dime. ¿Qué deseas hacer?`);
  }
 
  function fallback(agent) {
    agent.add(`No te entendí.`);
    agent.add(`Perdón, puedes repetirlo una vez más`);
  }

  //function getFromFirebase(agent) {
    //return firebaseAdmin.database().ref('data').once('value').then((snapshot) => {
      //const value = snapshot.child('text').val();
      //if(value!==null){
      //agent.add(value);
      //}
    //});
    
  //}
  
  
  function getFromFirebase(agent){
    //agent.add("hola");
	//return firebaseAdmin.database().ref('data').once('value').then((snapshot) => {
	//	const value = snapshot.child('text').val();
      //agent.add("hola");
		//if(value !== null){
		//	agent.add('La direccion es ${value}');
		//}
	//});
//}
  
  response.json('User already exists');
    const text = agent.parameters.text;
    return firebaseAdmin.database().ref('data').set({
      first_name: 'Raúl',
      last_name: 'Medina',
      text: text
      
    }), 
    firebaseAdmin.database().ref('data').once('value').then((snapshot) => {
    const value = snapshot.child('text').val();
    const value1 = snapshot.child('first_name').val();
    const value2 = snapshot.child('last_name').val();
      if(value!==null){
      agent.add(value+ value2+value1);
      }
    });
  }
  let intentMap = new Map();
  intentMap.set('Default Welcome Intent', welcome);
  intentMap.set('Default Fallback Intent', fallback);
  intentMap.set('getAddress', getFromFirebase);
  agent.handleRequest(intentMap);
});